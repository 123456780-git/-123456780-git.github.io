
import React, { useState, useEffect, useRef } from 'react';
import { Camera, Upload, Info, Sun, Moon, Leaf, X, Loader2, CheckCircle2, Search, ArrowRight, History, User, LogOut, AlertTriangle, ShieldCheck, Trash2, MessageCircle, Send } from 'lucide-react';
import { identifyPlant, chatWithExpert } from './geminiService';
import { AppState, View, PlantInfo, ChatMessage } from './types';

// Helper components
const Navbar: React.FC<{ 
  currentView: View; 
  setView: (v: View) => void;
  darkMode: boolean;
  toggleTheme: () => void;
  user: any;
  onLogout: () => void;
}> = ({ currentView, setView, darkMode, toggleTheme, user, onLogout }) => (
  <nav className="sticky top-0 z-50 glass border-b border-slate-200/50 dark:border-slate-800/50 px-4 py-3">
    <div className="max-w-6xl mx-auto flex items-center justify-between">
      <div 
        className="flex items-center gap-2 cursor-pointer group"
        onClick={() => setView('home')}
      >
        <div className="bg-emerald-600 p-2 rounded-xl text-white group-hover:rotate-12 transition-transform shadow-lg shadow-emerald-500/20">
          <Leaf size={20} />
        </div>
        <span className="font-bold text-xl tracking-tight text-emerald-800 dark:text-emerald-400">LeafID</span>
      </div>
      
      <div className="hidden lg:flex items-center gap-8">
        {(['home', 'history', 'about', 'contact'] as View[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`capitalize font-semibold text-sm transition-all relative ${
              currentView === v 
              ? 'text-emerald-600 dark:text-emerald-400' 
              : 'text-slate-500 dark:text-slate-400 hover:text-emerald-600'
            }`}
          >
            {v}
            {currentView === v && <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-emerald-500 rounded-full"></span>}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun size={20} className="text-amber-400" /> : <Moon size={20} className="text-slate-600" />}
        </button>
        
        {user ? (
          <div className="flex items-center gap-3 pl-3 border-l border-slate-200 dark:border-slate-800">
             <div className="hidden sm:block text-right">
               <p className="text-xs font-bold leading-none">{user.name}</p>
               <button onClick={onLogout} className="text-[10px] text-red-500 hover:underline">Logout</button>
             </div>
             <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center text-emerald-600">
               <User size={18} />
             </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setView('signin')}
              className="text-sm font-bold text-slate-600 dark:text-slate-400 px-3 py-2 hover:text-emerald-600 transition-colors"
            >
              Log In
            </button>
            <button 
              onClick={() => setView('signup')}
              className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:scale-105 transition-transform shadow-lg shadow-emerald-500/20"
            >
              Sign Up
            </button>
          </div>
        )}
      </div>
    </div>
  </nav>
);

const ChatBot: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  messages: ChatMessage[]; 
  onSendMessage: (msg: string) => void;
  currentPlant?: PlantInfo | null;
}> = ({ isOpen, onClose, messages, onSendMessage, currentPlant }) => {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-24 right-4 sm:right-8 w-[calc(100vw-2rem)] sm:w-96 h-[500px] max-h-[70vh] glass rounded-[2.5rem] shadow-2xl z-[100] flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
      <div className="bg-emerald-600 p-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <MessageCircle size={18} />
          </div>
          <div>
            <p className="text-sm font-black uppercase tracking-tighter leading-none">Plant Expert</p>
            <p className="text-[10px] opacity-70">Always active AI assistant</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <X size={18} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-8">
            <p className="text-slate-500 text-sm font-medium">
              Ask me anything about {currentPlant ? currentPlant.commonName : "plants"}!
            </p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm font-medium ${
              msg.role === 'user' 
              ? 'bg-emerald-600 text-white rounded-br-none shadow-lg' 
              : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none shadow-sm border border-slate-100 dark:border-slate-700'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form 
        onSubmit={(e) => { e.preventDefault(); if (input.trim()) { onSendMessage(input); setInput(""); } }}
        className="p-4 border-t border-slate-100 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-900/50 flex gap-2"
      >
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your question..." 
          className="flex-1 bg-white dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
        />
        <button className="bg-emerald-600 text-white p-3 rounded-xl hover:scale-105 active:scale-95 transition-all">
          <Send size={18} />
        </button>
      </form>
    </div>
  );
};

const ToxicityBadge: React.FC<{ isToxic: boolean; details: string }> = ({ isToxic, details }) => (
  <div className={`relative p-6 transition-all animate-in zoom-in duration-700 ${isToxic ? 'text-red-900 dark:text-red-100' : 'text-emerald-900 dark:text-emerald-100'}`}>
    <div className={`liquid-glass absolute inset-0 -z-10 ${isToxic ? 'liquid-glass-red' : ''}`}></div>
    <div className="flex flex-col items-center text-center">
      {isToxic ? <AlertTriangle size={40} className="mb-2 text-red-500" /> : <ShieldCheck size={40} className="mb-2 text-emerald-500" />}
      <h3 className="text-xl font-black uppercase tracking-widest">{isToxic ? 'Hazardous' : 'Safe Specimen'}</h3>
      <p className="text-sm font-medium mt-2 opacity-80 max-w-[200px]">{details}</p>
    </div>
  </div>
);

const PlantTable: React.FC<{ data: PlantInfo }> = ({ data }) => (
  <div className="mt-8 overflow-hidden rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
    <div className="bg-slate-50/50 dark:bg-slate-800/50 p-5 border-b border-slate-200 dark:border-slate-800">
      <h3 className="font-bold text-lg flex items-center gap-2">
        <Info size={18} className="text-emerald-600" />
        Botanical Specifications
      </h3>
    </div>
    <div className="divide-y divide-slate-100 dark:divide-slate-800/50">
      {[
        { label: "Scientific Name", value: data.scientificName, italic: true },
        { label: "Family", value: data.family },
        { label: "Origin", value: data.origin },
      ].map((row, idx) => (
        <div key={idx} className="grid grid-cols-3 p-5">
          <span className="text-slate-500 dark:text-slate-400 font-semibold text-sm">{row.label}</span>
          <span className={`col-span-2 font-bold ${row.italic ? 'italic' : ''}`}>{row.value}</span>
        </div>
      ))}
      <div className="grid grid-cols-3 p-5">
        <span className="text-slate-500 dark:text-slate-400 font-semibold text-sm">Care Requirements</span>
        <div className="col-span-2 grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
          {Object.entries(data.care).map(([key, val]) => (
            <div key={key}>
              <p className="text-[10px] uppercase text-emerald-600 font-black mb-1 tracking-tighter">{key}</p>
              <p className="font-medium text-slate-700 dark:text-slate-300 leading-tight">{val}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => {
    const savedHistory = localStorage.getItem('plant_history');
    const savedUser = localStorage.getItem('plant_user');
    return {
      view: 'home',
      darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches,
      isIdentifying: false,
      result: null,
      error: null,
      history: savedHistory ? JSON.parse(savedHistory) : [],
      user: savedUser ? JSON.parse(savedUser) : null,
      isChatOpen: false,
      chatMessages: []
    };
  });

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('plant_history', JSON.stringify(state.history));
    localStorage.setItem('plant_user', JSON.stringify(state.user));
  }, [state.history, state.user]);

  useEffect(() => {
    if (state.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.darkMode]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64Full = e.target?.result as string;
      setPreviewUrl(base64Full);
      const pureBase64 = base64Full.split(',')[1];
      
      setState(prev => ({ ...prev, isIdentifying: true, error: null, result: null }));
      
      try {
        const info = await identifyPlant(pureBase64);
        const resultWithMeta = { 
          ...info, 
          id: crypto.randomUUID(), 
          timestamp: Date.now(),
          image: base64Full 
        };
        
        setState(prev => ({ 
          ...prev, 
          result: resultWithMeta, 
          isIdentifying: false,
          history: [resultWithMeta, ...prev.history].slice(0, 20) 
        }));
      } catch (err: any) {
        setState(prev => ({ ...prev, error: err.message, isIdentifying: false }));
      }
    };
    reader.readAsDataURL(file);
  };

  const deleteHistoryItem = (id: string) => {
    setState(prev => ({ ...prev, history: prev.history.filter(i => i.id !== id) }));
  };

  const clearHistory = () => {
    if (confirm("Delete all identification history?")) {
      setState(prev => ({ ...prev, history: [] }));
    }
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setState(prev => ({ 
      ...prev, 
      user: { name: "Leaf Explorer", email: "explorer@leafid.ai" },
      view: 'home'
    }));
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setState(prev => ({ 
      ...prev, 
      user: { name: "New Gardener", email: "fresh@leafid.ai" },
      view: 'home'
    }));
  };

  const onSendMessage = async (text: string) => {
    const newUserMsg: ChatMessage = { role: 'user', text };
    setState(prev => ({ ...prev, chatMessages: [...prev.chatMessages, newUserMsg] }));
    
    const response = await chatWithExpert(text, state.chatMessages, state.result || undefined);
    const newModelMsg: ChatMessage = { role: 'model', text: response };
    setState(prev => ({ ...prev, chatMessages: [...prev.chatMessages, newModelMsg] }));
  };

  const resetSearch = () => {
    setPreviewUrl(null);
    setState(prev => ({ ...prev, result: null, error: null, view: 'home' }));
  };

  const renderContent = () => {
    switch (state.view) {
      case 'signin':
        return (
          <div className="max-w-md mx-auto py-20 px-6">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-500 to-blue-500"></div>
              <div className="bg-emerald-100 dark:bg-emerald-900/40 w-16 h-16 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto mb-6">
                <Leaf size={32} />
              </div>
              <h2 className="text-3xl font-black mb-2">Welcome Back</h2>
              <p className="text-slate-500 mb-8 font-medium">Log in to your plant journal</p>
              <form className="space-y-4" onSubmit={handleSignIn}>
                <input type="email" placeholder="Email Address" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500 outline-none" required />
                <input type="password" placeholder="Password" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500 outline-none" required />
                <button type="submit" className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-xl shadow-emerald-500/20 hover:scale-[1.02] active:scale-95 transition-all">
                  Sign In
                </button>
              </form>
              <div className="mt-8 flex items-center justify-center gap-2 text-sm font-medium text-slate-400">
                <span>Don't have an account?</span>
                <button onClick={() => setState(p => ({ ...p, view: 'signup' }))} className="text-emerald-600 font-bold">Sign Up</button>
              </div>
            </div>
          </div>
        );

      case 'signup':
        return (
          <div className="max-w-md mx-auto py-20 px-6">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-500 to-blue-500"></div>
              <div className="bg-emerald-100 dark:bg-emerald-900/40 w-16 h-16 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto mb-6">
                <Leaf size={32} />
              </div>
              <h2 className="text-3xl font-black mb-2">Create Account</h2>
              <p className="text-slate-500 mb-8 font-medium">Start your digital herbarium today</p>
              <form className="space-y-4" onSubmit={handleSignUp}>
                <input type="text" placeholder="Full Name" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500 outline-none" required />
                <input type="email" placeholder="Email Address" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500 outline-none" required />
                <input type="password" placeholder="Password" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500 outline-none" required />
                <button type="submit" className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-xl shadow-emerald-500/20 hover:scale-[1.02] active:scale-95 transition-all">
                  Get Started
                </button>
              </form>
              <div className="mt-8 flex items-center justify-center gap-2 text-sm font-medium text-slate-400">
                <span>Already have an account?</span>
                <button onClick={() => setState(p => ({ ...p, view: 'signin' }))} className="text-emerald-600 font-bold">Log In</button>
              </div>
            </div>
          </div>
        );

      case 'history':
        return (
          <div className="max-w-6xl mx-auto py-12 px-6">
            <div className="flex items-center justify-between mb-10">
              <div>
                <h1 className="text-4xl font-black mb-2">My Garden</h1>
                <p className="text-slate-500 font-medium">Your identification history ({state.history.length})</p>
              </div>
              {state.history.length > 0 && (
                <button onClick={clearHistory} className="flex items-center gap-2 text-red-500 font-bold hover:bg-red-50 dark:hover:bg-red-900/20 px-4 py-2 rounded-xl transition-all">
                  <Trash2 size={18} />
                  Clear All
                </button>
              )}
            </div>
            
            {state.history.length === 0 ? (
              <div className="text-center py-32 bg-slate-100 dark:bg-slate-900/50 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
                <History size={64} className="mx-auto text-slate-300 dark:text-slate-700 mb-6" />
                <h3 className="text-xl font-bold mb-2">No History Yet</h3>
                <p className="text-slate-500 mb-8">Start by identifying your first plant!</p>
                <button onClick={() => setState(p => ({ ...p, view: 'home' }))} className="px-8 py-3 bg-emerald-600 text-white font-black rounded-xl shadow-lg">Scan Now</button>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {state.history.map((item) => (
                  <div key={item.id} className="group bg-white dark:bg-slate-900 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all border border-slate-100 dark:border-slate-800">
                    <div className="relative h-48 overflow-hidden">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={item.commonName} />
                      <div className="absolute top-4 right-4">
                        <button onClick={() => deleteHistoryItem(item.id)} className="p-2 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-red-500 transition-colors">
                          <X size={16} />
                        </button>
                      </div>
                    </div>
                    <div className="p-6">
                      <p className="text-[10px] font-black uppercase tracking-tighter text-emerald-600 mb-1">{new Date(item.timestamp).toLocaleDateString()}</p>
                      <h3 className="font-extrabold text-xl mb-1 line-clamp-1">{item.commonName}</h3>
                      <p className="text-xs italic text-slate-500 mb-4 line-clamp-1">{item.scientificName}</p>
                      <button 
                        onClick={() => setState(p => ({ ...p, result: item, view: 'home' }))}
                        className="w-full py-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-sm font-bold flex items-center justify-center gap-2 group/btn"
                      >
                        View Details
                        <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'about':
        return (
          <div className="max-w-4xl mx-auto py-16 px-6">
             <div className="relative mb-20">
                <div className="absolute -top-10 -left-10 w-40 h-40 liquid-glass -z-10 opacity-50"></div>
                <h1 className="text-6xl font-black mb-8 leading-tight">Botany Meets <br/><span className="gradient-text">Intelligence.</span></h1>
                <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed font-medium">
                  LeafID leverages the world's most advanced AI to help you understand your plants better. Whether you're a professional botanist or a home gardener, our mission is to make plant knowledge accessible to all.
                </p>
             </div>
             
             <div className="grid md:grid-cols-2 gap-10">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800">
                   <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center mb-6"><ShieldCheck/></div>
                   <h3 className="text-xl font-black mb-3">Health & Safety</h3>
                   <p className="text-slate-500 font-medium leading-relaxed">Safety is our priority. We provide detailed toxicity information for both pets and humans on every scan.</p>
                </div>
                <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800">
                   <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex items-center justify-center mb-6"><Search/></div>
                   <h3 className="text-xl font-black mb-3">Flash Identification</h3>
                   <p className="text-slate-500 font-medium leading-relaxed">Utilizing Gemini AI Vision, we deliver results in under 5 seconds with extreme botanical accuracy.</p>
                </div>
             </div>
          </div>
        );

      case 'contact':
        return (
          <div className="max-w-5xl mx-auto py-20 px-6 grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-black mb-6">Let's Talk <span className="gradient-text">Plants.</span></h1>
              <p className="text-lg text-slate-500 mb-8 font-medium">Need help with the app or have a rare species you want us to support? Our botanical experts are here for you.</p>
              <div className="space-y-4">
                 <div className="flex items-center gap-4 text-slate-600 dark:text-slate-300 font-bold">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center"><Search size={18}/></div>
                    hello@leafid.ai
                 </div>
                 <div className="flex items-center gap-4 text-slate-600 dark:text-slate-300 font-bold">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center"><Leaf size={18}/></div>
                    @leafid_app
                 </div>
              </div>
            </div>
            <form className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-800 space-y-4">
              <input type="text" placeholder="Full Name" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none" />
              <input type="email" placeholder="Email Address" className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none" />
              <textarea placeholder="Tell us what's on your mind..." rows={4} className="w-full px-5 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none resize-none"></textarea>
              <button className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-xl shadow-emerald-500/20 hover:scale-[1.02] active:scale-95 transition-all">
                Send Inquiry
              </button>
            </form>
          </div>
        );

      default:
        return (
          <div className="max-w-6xl mx-auto px-4 py-8">
            {/* Hero Section */}
            {!state.result && !state.isIdentifying && !state.error && (
              <div className="text-center py-12 lg:py-24 relative overflow-hidden">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-20 dark:opacity-10 pointer-events-none">
                    <div className="absolute top-0 left-1/4 w-64 h-64 liquid-glass bg-blue-500 blur-3xl"></div>
                    <div className="absolute bottom-0 right-1/4 w-64 h-64 liquid-glass bg-emerald-500 blur-3xl"></div>
                </div>
                
                <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-black mb-8 tracking-widest uppercase">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  Gemini AI Vision Active
                </div>
                
                <h1 className="text-6xl md:text-8xl font-black mb-8 tracking-tighter text-slate-900 dark:text-white leading-[0.9]">
                  Identify Your <br/><span className="gradient-text">World In Green</span>
                </h1>
                
                <p className="text-xl text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto font-medium leading-relaxed">
                  Join 50k+ plant enthusiasts identifying and caring for nature with the world's most precise botanical AI.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-5 max-w-lg mx-auto">
                  <label className="w-full group relative cursor-pointer flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black py-6 px-10 rounded-[2rem] shadow-2xl shadow-emerald-500/30 transition-all transform hover:-translate-y-1 active:scale-95">
                    <Camera size={24} />
                    Capture Photo
                    <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
                  </label>
                  <label className="w-full group relative cursor-pointer flex items-center justify-center gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 font-black py-6 px-10 rounded-[2rem] transition-all hover:border-emerald-500 shadow-lg">
                    <Upload size={24} className="text-emerald-500" />
                    Upload Image
                    <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                  </label>
                </div>
              </div>
            )}

            {/* Loading State */}
            {state.isIdentifying && (
              <div className="flex flex-col items-center justify-center py-24">
                <div className="relative mb-12">
                   <div className="w-56 h-56 liquid-glass animate-morph flex items-center justify-center relative overflow-hidden">
                      {previewUrl && <img src={previewUrl} className="w-full h-full object-cover opacity-60 scale-125 grayscale" alt="Identifying..." />}
                      <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/20 to-transparent"></div>
                   </div>
                   <div className="absolute -bottom-4 -right-4 bg-white dark:bg-slate-800 p-4 rounded-full shadow-2xl border-4 border-slate-50 dark:border-slate-950">
                      <Loader2 size={32} className="text-emerald-600 animate-spin" />
                   </div>
                </div>
                <h2 className="text-3xl font-black mb-3">Analyzing Specimen</h2>
                <p className="text-slate-500 font-medium">Extracting chlorophyll and botanical patterns...</p>
              </div>
            )}

            {/* Error State */}
            {state.error && (
              <div className="max-w-lg mx-auto bg-white dark:bg-slate-900 border border-red-100 dark:border-red-900/40 p-12 rounded-[3rem] text-center shadow-2xl">
                <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center text-red-500 mx-auto mb-6">
                  <X size={40} />
                </div>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-3">Search Failed</h3>
                <p className="text-slate-500 font-medium mb-8 leading-relaxed">{state.error}</p>
                <button 
                  onClick={resetSearch}
                  className="w-full py-4 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-black rounded-2xl transition-all"
                >
                  Try Again
                </button>
              </div>
            )}

            {/* Results Section */}
            {state.result && (
              <div className="animate-in fade-in slide-in-from-bottom-12 duration-700">
                <div className="flex items-center justify-between mb-8">
                  <button 
                    onClick={resetSearch}
                    className="flex items-center gap-2 text-slate-400 hover:text-emerald-600 font-black transition-all"
                  >
                    <ArrowRight className="rotate-180" size={20} />
                    New Search
                  </button>
                  <div className="flex items-center gap-3">
                    <History size={18} className="text-slate-400" />
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Saved to History</span>
                  </div>
                </div>
                
                <div className="grid lg:grid-cols-2 gap-16 items-start">
                  <div className="space-y-8 lg:sticky lg:top-24">
                    <div className="relative group">
                      <div className="absolute -inset-4 bg-emerald-500/10 blur-2xl rounded-[3rem] group-hover:bg-emerald-500/20 transition-all duration-1000"></div>
                      <div className="relative rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white dark:border-slate-800">
                        {previewUrl ? (
                          <img src={previewUrl} className="w-full aspect-square lg:aspect-[4/5] object-cover" alt="Result" />
                        ) : (
                           <img src={state.result.image} className="w-full aspect-square lg:aspect-[4/5] object-cover" alt="Result" />
                        )}
                        <div className="absolute top-6 right-6 scale-125 lg:scale-150">
                           <ToxicityBadge isToxic={state.result.toxicity.isToxic} details={state.result.toxicity.details} />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-12">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 text-[10px] font-black rounded-lg uppercase tracking-widest">
                          {state.result.family}
                        </span>
                      </div>
                      <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter leading-none">{state.result.commonName}</h1>
                      <p className="text-xl text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                        {state.result.description}
                      </p>
                    </div>

                    <div className="relative p-10 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-[3rem] text-white shadow-2xl shadow-emerald-500/20">
                      <div className="absolute top-0 right-0 p-8 opacity-20"><Leaf size={100}/></div>
                      <h4 className="flex items-center gap-2 font-black text-emerald-200 mb-4 tracking-widest uppercase text-xs">
                        <CheckCircle2 size={16} />
                        Did you know?
                      </h4>
                      <p className="text-2xl font-bold leading-tight relative z-10">
                        "{state.result.funFact}"
                      </p>
                    </div>

                    <PlantTable data={state.result} />
                  </div>
                </div>
              </div>
            )}

            {/* How it Works Section */}
            {!state.result && !state.isIdentifying && state.view === 'home' && (
              <div className="mt-40 mb-20">
                <div className="text-center mb-20">
                  <h2 className="text-5xl font-black mb-4 tracking-tight">Simple. Green. Smart.</h2>
                  <p className="text-slate-500 font-medium text-lg">Harness the power of AI in three steps</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                  {[
                    { Icon: Camera, color: "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600", title: "Capture", desc: "Snap a high-resolution photo of leaves, flowers, or bark." },
                    { Icon: Search, color: "bg-blue-100 dark:bg-blue-900/30 text-blue-600", title: "Analyze", desc: "Our Flash AI cross-references 1M+ botanical data points." },
                    { Icon: ShieldCheck, color: "bg-purple-100 dark:bg-purple-900/30 text-purple-600", title: "Care", desc: "Get toxicity alerts and professional care guides instantly." }
                  ].map((step, i) => (
                    <div key={i} className="group p-10 bg-white dark:bg-slate-900 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-all hover:shadow-2xl hover:-translate-y-2">
                      <div className={`${step.color} w-20 h-20 rounded-[1.5rem] flex items-center justify-center mb-8 group-hover:scale-110 transition-transform`}>
                        <step.Icon size={32} />
                      </div>
                      <h3 className="text-2xl font-black mb-4">{step.title}</h3>
                      <p className="text-slate-500 font-medium leading-relaxed">{step.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen transition-colors duration-300 bg-slate-50 dark:bg-slate-950 dark:text-slate-100 pb-24 overflow-x-hidden">
      <Navbar 
        currentView={state.view} 
        setView={(v) => setState(p => ({ ...p, view: v }))} 
        darkMode={state.darkMode} 
        toggleTheme={() => setState(p => ({ ...p, darkMode: !p.darkMode }))}
        user={state.user}
        onLogout={() => setState(p => ({ ...p, user: null }))}
      />
      <main className="relative">
        {renderContent()}
      </main>

      {/* Floating Chat Button */}
      <button 
        onClick={() => setState(prev => ({ ...prev, isChatOpen: !prev.isChatOpen }))}
        className={`fixed bottom-8 right-8 w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all z-[101] ${
          state.isChatOpen 
          ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rotate-90' 
          : 'bg-emerald-600 text-white hover:scale-110 hover:-translate-y-1'
        }`}
      >
        {state.isChatOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>

      <ChatBot 
        isOpen={state.isChatOpen} 
        onClose={() => setState(p => ({ ...p, isChatOpen: false }))} 
        messages={state.chatMessages} 
        onSendMessage={onSendMessage} 
        currentPlant={state.result}
      />
      
      {/* Liquid Glass Mobile Footer CTA */}
      {!state.result && !state.isIdentifying && state.view === 'home' && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[90%] max-w-sm md:hidden z-50">
          <label className="flex items-center justify-center gap-3 bg-emerald-600 text-white font-black py-5 rounded-[2rem] shadow-[0_20px_50px_rgba(16,185,129,0.3)] cursor-pointer active:scale-95 transition-all">
            <Camera size={24} />
            Scan Specimen
            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
          </label>
        </div>
      )}
    </div>
  );
};

export default App;
