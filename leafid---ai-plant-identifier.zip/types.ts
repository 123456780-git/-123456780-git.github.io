
export interface PlantCare {
  water: string;
  light: string;
  soil: string;
  humidity: string;
  fertilizer: string;
}

export interface PlantInfo {
  id: string;
  timestamp: number;
  image?: string;
  commonName: string;
  scientificName: string;
  family: string;
  origin: string;
  description: string;
  toxicity: {
    isToxic: boolean;
    details: string;
  };
  care: PlantCare;
  funFact: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export type View = 'home' | 'about' | 'contact' | 'history' | 'signin' | 'signup';

export interface AppState {
  view: View;
  darkMode: boolean;
  isIdentifying: boolean;
  result: PlantInfo | null;
  error: string | null;
  history: PlantInfo[];
  user: { name: string; email: string } | null;
  isChatOpen: boolean;
  chatMessages: ChatMessage[];
}
